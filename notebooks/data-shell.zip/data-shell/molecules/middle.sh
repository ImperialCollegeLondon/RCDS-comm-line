# this script shows a range of lines from a file 
# usage: bash middle.sh filename end_line total_lines
head -n $2 $1 | tail -n $3
echo $1
