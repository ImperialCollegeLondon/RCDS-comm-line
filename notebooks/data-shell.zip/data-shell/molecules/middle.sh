# this shows line 10 to 15 from a file specified on the command line
# usage: bash middle.sh file

echo $1
head -n 15 $1 | tail -n 5

