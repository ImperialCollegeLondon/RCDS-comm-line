# this script shows lines 10 to 15 from a file
# usage: bash middle.sh filename
head -n $2 $1 | tail -n $3
echo $1
