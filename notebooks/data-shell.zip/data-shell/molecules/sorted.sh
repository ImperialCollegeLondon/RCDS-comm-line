# this script counts number of lines in files and sorts the output numerically
wc -l $@ | sort -n

