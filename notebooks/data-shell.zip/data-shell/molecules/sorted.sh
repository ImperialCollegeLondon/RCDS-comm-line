wc -l $@ | sort -n

