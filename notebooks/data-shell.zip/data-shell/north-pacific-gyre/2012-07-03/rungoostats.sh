# this runs goostats on all given files
# usage: bash rungoostats "files_with_wildcard" correct_line_count


if [ $# -ne 2 ]
then
    echo "usage: bash rungoostats \"files_with_wildcard\" line_count"
    exit
fi

for filename in $1
do
  echo $filename
  # this assigns line count to a variable
  LINECOUNT=$(cat $filename | wc -l)
  if [ $LINECOUNT -ne $2 ]
  then
      echo "Error: $filename has $LINECOUNT lines."
  else
      bash goostats $filename stats-$filename
  fi
done
