for filename in NENE*[AB].txt
do
  echo "bash goostats $filename stats-$filename"
done


