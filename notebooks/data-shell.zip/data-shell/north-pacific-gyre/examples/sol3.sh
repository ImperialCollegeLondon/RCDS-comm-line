for filename in NENE*[AB].txt
do
  echo $filename
  LINECOUNT=$(cat $filename | wc -l)
  if [ $LINECOUNT -ne 300  ]
  then
     echo "Skipping: $filename has $LINECOUNT lines."
  else
     echo "bash goostats $filename stats-$filename"
  fi
done


