echo $1
for filename in $1
do
  echo $filename
  LINECOUNT=$(cat $filename | wc -l)
  if [ $LINECOUNT -ne $2  ]
  then
     echo "Error: $filename has $LINECOUNT lines."
  else
     echo "bash goostats $filename stats-$filename"
  fi
done


