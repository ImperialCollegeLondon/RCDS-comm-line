# this runs goostats on all given files
# arg 1: filenames using wildcard, all in quotes
# arg 2: correct line count per file

if [ $# -ne 2  ]
then
 echo "usage: bash rungoostats.sh \"files\" line_count"
 exit
fi

for filename in $1
do
  echo $filename
  LINECOUNT=$(cat $filename | wc -l)
  if [ $LINECOUNT -ne $2  ]
  then
     echo "Error: $filename has $LINECOUNT lines."
  else
     echo "bash goostats $filename stats-$filename"
  fi
done


